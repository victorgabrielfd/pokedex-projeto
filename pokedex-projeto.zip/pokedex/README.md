# Pokédex UC33

Projeto de estudo: serviço web em TypeScript com Node.js e Express que consulta a PokéAPI. A página HTML/CSS/JavaScript consome somente a nossa API.

## Requisitos

- Node.js 22 ou superior
- npm

## Instalação

```bash
npm install
```

## Executar em desenvolvimento

```bash
npm run dev
```

Abra http://localhost:3000 no navegador.

## Compilar e executar a versão compilada

```bash
npm run build
npm start
```

## Rota da API

`GET /api/pokemons/:termo`

O parâmetro `termo` aceita o nome ou o número do Pokémon.

Exemplo: `GET http://localhost:3000/api/pokemons/pikachu`

Resposta de sucesso:

```json
{
  "numero": 25,
  "nome": "pikachu",
  "tipos": ["electric"],
  "imagem": "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/25.png"
}
```

Respostas de erro usam o formato `{ "erro": "mensagem" }`:
- `400`: nome ou número em formato inválido.
- `404`: Pokémon ou rota não encontrada.
- `503`: PokéAPI indisponível ou sem resposta dentro do limite de tempo.
- `500`: erro interno inesperado.

## Recursos

- Cache em memória por nome e número.
- Limite de 5 segundos para a consulta externa.
- Validação do termo no servidor.
- A página conversa somente com `/api/pokemons/...`.
- Exibição segura de texto com `textContent`, sem `innerHTML`.
- Busca por nome/número e navegação anterior/próximo.

## Desafios extras

- Cores CSS para os 18 tipos.
- Visual personalizado da Pokédex.
