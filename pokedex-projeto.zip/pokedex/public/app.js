const $ = (id) => document.getElementById(id);

let numeroAtual = 0;

async function pedirPokemon(termo) {
  let resposta;

  try {
    resposta = await fetch(
      `/api/pokemons/${encodeURIComponent(termo)}`
    );
  } catch {
    throw new Error("Sem conexão com o servidor. Ele está rodando?");
  }

  const corpo = await resposta.json().catch(() => ({}));

  if (!resposta.ok) {
    throw new Error(corpo.erro ?? `Erro ${resposta.status}`);
  }

  return corpo;
}

function mostrarAviso(texto, tipo = "erro") {
  $("aviso").textContent = texto;
  $("aviso").className = `aviso ${tipo}`;
  $("aviso").hidden = false;
}

function mostrarPokemon(pokemon) {
  numeroAtual = pokemon.numero;

  $("aviso").hidden = true;
  $("numero").textContent =
    `#${String(pokemon.numero).padStart(3, "0")}`;
  $("nome").textContent = pokemon.nome;

  // Cria os elementos da lista sem inserir HTML vindo da API.
  $("tipos").replaceChildren(
    ...pokemon.tipos.map((tipo) => {
      const item = document.createElement("li");
      item.textContent = tipo;
      item.className = `tipo tipo-${tipo}`;
      return item;
    })
  );

  const imagem = $("imagem");
  imagem.hidden = !pokemon.imagem;

  if (pokemon.imagem) {
    imagem.src = pokemon.imagem;
    imagem.alt = pokemon.nome;
  } else {
    imagem.removeAttribute("src");
    imagem.alt = "";
  }

  $("termo").value = pokemon.nome;
}

function travarBotoes(travar) {
  document.querySelectorAll("button").forEach((botao) => {
    botao.disabled = travar;
  });

  if (!travar) {
    $("anterior").disabled = numeroAtual <= 1;
  }
}

async function buscar(termo) {
  if (!termo) {
    mostrarAviso("Digite o nome ou o número de um Pokémon.");
    return;
  }

  mostrarAviso("Buscando Pokémon...", "info");
  travarBotoes(true);

  try {
    const pokemon = await pedirPokemon(termo);
    mostrarPokemon(pokemon);
  } catch (erro) {
    mostrarAviso(
      erro instanceof Error ? erro.message : "Ocorreu um erro inesperado."
    );
  } finally {
    travarBotoes(false);
  }
}

$("imagem").addEventListener("error", () => {
  $("imagem").hidden = true;
});

$("busca").addEventListener("submit", (evento) => {
  evento.preventDefault();
  buscar($("termo").value.trim());
});

$("anterior").addEventListener("click", () => {
  if (numeroAtual > 1) buscar(String(numeroAtual - 1));
});

$("proximo").addEventListener("click", () => {
  buscar(String(numeroAtual + 1));
});

// Mostra o primeiro Pokémon assim que a página abre.
buscar("1");