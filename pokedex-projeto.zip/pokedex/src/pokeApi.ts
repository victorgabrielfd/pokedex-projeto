// Integração com a PokéAPI: somente este arquivo conhece o endereço externo.
const URL_BASE = "https://pokeapi.co/api/v2";
const TEMPO_LIMITE_MS = 5000;
const NOME_VALIDO = /^[a-z0-9-]{1,40}$/;

// Contrato que a nossa API entrega para a página.
export interface Pokemon {
  numero: number;
  nome: string;
  tipos: string[];
  imagem: string | null;
}

// Apenas os campos da resposta externa que realmente utilizamos.
interface RespostaPokeApi {
  id: number;
  name: string;
  types: { type: { name: string } }[];
  sprites: { front_default: string | null };
}

const cache = new Map<string, Pokemon>();

export class ErroDaApi extends Error {
  constructor(public readonly status: number, mensagem: string) {
    super(mensagem);
    this.name = "ErroDaApi";
  }
}

function normalizar(termo: string): string {
  const nome = termo.trim().toLowerCase();

  if (!NOME_VALIDO.test(nome)) {
    throw new ErroDaApi(
      400,
      `Pokémon "${termo}" inválido: use o nome (ex.: pikachu) ou o número (ex.: 25)`
    );
  }

  return nome;
}

function resumir(dados: RespostaPokeApi): Pokemon {
  return {
    numero: dados.id,
    nome: dados.name,
    tipos: dados.types.map((item) => item.type.name),
    imagem: dados.sprites.front_default
  };
}

export async function buscarPokemon(termo: string): Promise<Pokemon> {
  const nome = normalizar(termo);

  // Se já consultamos este Pokémon, devolvemos o objeto guardado.
  const guardado = cache.get(nome);
  if (guardado) return guardado;

  let resposta: Response;

  try {
    resposta = await fetch(`${URL_BASE}/pokemon/${nome}`, {
      signal: AbortSignal.timeout(TEMPO_LIMITE_MS)
    });
  } catch {
    throw new ErroDaApi(
      503,
      "A PokéAPI não respondeu. Tente de novo em instantes."
    );
  }

  if (resposta.status === 404) {
    throw new ErroDaApi(404, `Pokémon ${nome} não encontrado`);
  }

  if (!resposta.ok) {
    throw new ErroDaApi(
      503,
      "A PokéAPI está com problemas. Tente de novo em instantes."
    );
  }

  let dados: RespostaPokeApi;
  try {
    dados = (await resposta.json()) as RespostaPokeApi;
  } catch {
    throw new ErroDaApi(503, "A PokéAPI retornou uma resposta inválida.");
  }

  const pokemon = resumir(dados);

  // Permite encontrar o mesmo Pokémon pelo nome ou pelo número.
  cache.set(nome, pokemon);
  cache.set(String(pokemon.numero), pokemon);

  return pokemon;
}